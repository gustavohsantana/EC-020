/*
    FreeRTOS V6.1.1 - Copyright (C) 2011 Real Time Engineers Ltd.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation AND MODIFIED BY the FreeRTOS exception.
 ***NOTE*** The exception to the GPL is included to allow you to distribute
    a combined work that includes FreeRTOS without being obliged to provide the
    source code for proprietary components outside of the FreeRTOS kernel.
    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
    more details. You should have received a copy of the GNU General Public 
    License and the FreeRTOS license exception along with FreeRTOS; if not it 
    can be viewed here: http://www.freertos.org/a00114.html and also obtained 
    by writing to Richard Barry, contact details for whom are available on the
    FreeRTOS WEB site.

    1 tab == 4 spaces!

    http://www.FreeRTOS.org - Documentation, latest information, license and
    contact details.

    http://www.SafeRTOS.com - A version that is certified for use in safety
    critical systems.

    http://www.OpenRTOS.com - Commercial support, development, porting,
    licensing and training services.
 */

/* FreeRTOS.org includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_i2c.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_ssp.h"
#include "lpc17xx_adc.h"
#include "lpc17xx_timer.h"
#include "lpc17xx.h"
#include "lpc17xx_uart.h"
#define UART_DEV LPC_UART3
#include "light.h"
#include "oled.h"
#include "temp.h"
#include "acc.h"




/* Demo includes. */
#include "basic_io.h"


/* The tasks to be created.  Two instances are created of the sender task while
only a single instance is created of the receiver task. */
static void vSenderTask( void *pvParameters );
static void vReceiverTask( void *pvParameters );
static void vUartTask( void *pvParameters );
static void init_adc(void);
static void init_i2c(void);
static void init_ssp(void);
static void intToString(int value, uint8_t* pBuf, uint32_t len, uint32_t base);
static void init_uart3(void);
static void vSensorTemptask( void *pvParameters );
static void VSensorLumitask( void *pvParameters );
static uint32_t getTicks(void);
static uint32_t msTicks = 0;
/*-----------------------------------------------------------*/

/* Declare a variable of type xQueueHandle.  This is used to store the queue
that is accessed by all three tasks. */
xQueueHandle xQueue;
static uint8_t buf[10];
static uint8_t buf2[10];
uint32_t len;

int main( void )
{
	/* The queue is created to hold a maximum of 5 long values. */
	xQueue = xQueueCreate( 5, sizeof( uint8_t ) );

	if( xQueue != NULL )
	{
		init_uart3();
		init_i2c();
		init_ssp();
		init_adc();

		oled_init();
		light_init();
		acc_init();
		temp_init (&xTaskGetTickCount);


		light_enable();
		light_setRange(LIGHT_RANGE_4000);

		oled_clearScreen(OLED_COLOR_WHITE);

		oled_putString(1,1,  (uint8_t*)"Temp  : ", OLED_COLOR_BLACK, OLED_COLOR_WHITE);
		oled_putString(1,9,  (uint8_t*)"Luz  : ", OLED_COLOR_BLACK, OLED_COLOR_WHITE);


		/* Create two instances of the task that will write to the queue.  The
		parameter is used to pass the value that the task should write to the queue,
		so one task will continuously write 100 to the queue while the other task 
		will continuously write 200 to the queue.  Both tasks are created at
		priority 1. */
		xTaskCreate( vSenderTask, "Sender1", 240, ( void * ) 100, 1, NULL );
		xTaskCreate( vUartTask, "Sender2", 240, ( void * ) 200, 1, NULL );
		xTaskCreate( vSensorTemptask, "Sender2", 240, ( void * ) 200, 1, NULL );
		xTaskCreate( VSensorLumitask, "Sender2", 240, ( void * ) 200, 1, NULL );


		/* Create the task that will read from the queue.  The task is created with
		priority 2, so above the priority of the sender tasks. */
		//xTaskCreate( vReceiverTask, "Receiver", 240, NULL, 2, NULL );

		/* Start the scheduler so the created tasks start executing. */
		vTaskStartScheduler();
	}
	else
	{
		/* The queue could not be created. */
	}

	/* If all is well we will never reach here as the scheduler will now be
    running the tasks.  If we do reach here then it is likely that there was 
    insufficient heap memory available for a resource to be created. */
	for( ;; );
	return 0;
}
/*-----------------------------------------------------------*/

static void vSensorTemptask( void *pvParameters )
{

	int32_t t = 0;
	int32_t t2 = 0;

	for(;;){
		vPrintString( "vSensorTemptask.\r\n" );
		t = temp_read();
		t2 = (t*26)/273;
		intToString(t2, buf, 10, 10);
		vTaskDelay( 100 / portTICK_RATE_MS );

		//taskYIELD();
	}
}

static void VSensorLumitask( void *pvParameters )
{
	uint32_t lux = 0;

	for(;;){
		vPrintString( "VSensorLumitask.\r\n" );

		lux = light_read();
		intToString(lux, buf2, 10, 10);
		vTaskDelay( 100 / portTICK_RATE_MS );

		//taskYIELD();
	}


}





static void vUartTask( void *pvParameters )
{

	uint8_t data;
	portBASE_TYPE xStatus;

	for(;;){
		vPrintString( "vUartTask.\r\n" );
		if(UART_Receive(UART_DEV, &data, 1, NONE_BLOCKING) >0){
			xStatus = xQueueSendToBack( xQueue, &data, 0 );

			if( xStatus != pdPASS )
			{
				/* We could not write to the queue because it was full � this must
				be an error as the queue should never contain more than one item! */
				vPrintString( "Could not send to the queue.\r\n" );

			}

		}
		vTaskDelay( 50 / portTICK_RATE_MS );


	}




}

static void vSenderTask( void *pvParameters )
{
	uint8_t lReceivedValue;
	portBASE_TYPE xStatus;
	const portTickType xTicksToWait = 100 / portTICK_RATE_MS;

	char str[10];
	char str2[10];

	/* As per most tasks, this task is implemented within an infinite loop. */
	for( ;; )
	{

		xStatus = xQueueReceive( xQueue, &lReceivedValue, xTicksToWait );

		if( xStatus == pdPASS )
		{

			vPrintString( "vSenderTask.\r\n" );
			switch (lReceivedValue) {

			case '0':
				oled_fillRect((1+9*6),1, 80, 8, OLED_COLOR_WHITE);
				oled_putString((1+9*6),1, buf, OLED_COLOR_BLACK, OLED_COLOR_WHITE);


				UART_SendString(UART_DEV, (uint8_t*) buf);

				UART_SendString(UART_DEV, (uint8_t*)" temperatura\r\n");

				break;

			case '1':

				oled_fillRect((1+9*6),9, 80, 16, OLED_COLOR_WHITE);
				oled_putString((1+9*6),9, buf2, OLED_COLOR_BLACK, OLED_COLOR_WHITE);

				UART_SendString(UART_DEV, (uint8_t*) buf2);
				UART_SendString(UART_DEV, (uint8_t*)"luminosidade \r\n");

				break;

			case '2':
				oled_fillRect((1+9*6),9, 80, 16, OLED_COLOR_WHITE);
				oled_putString((1+9*6),9, buf, OLED_COLOR_BLACK, OLED_COLOR_WHITE);

				oled_fillRect((1+9*6),1, 80, 8, OLED_COLOR_WHITE);
				oled_putString((1+9*6),1, buf2, OLED_COLOR_BLACK, OLED_COLOR_WHITE);



				UART_SendString(UART_DEV, (uint8_t*) buf);
				UART_SendString(UART_DEV, (uint8_t*)" temperatura  ");


				UART_SendString(UART_DEV, (uint8_t*) buf2);
				UART_SendString(UART_DEV, (uint8_t*)" luminosidade \r\n");

				break;

			default:

				break;


			}

		}
		else
		{
			/* We did not receive anything from the queue even after waiting for 100ms.
			This must be an error as the sending tasks are free running and will be
			continuously writing to the queue. */
			vPrintString( "Could not receive from the queue.\r\n" );
		}




	}
}
/*-----------------------------------------------------------*/

static void vReceiverTask( void *pvParameters )
{
	/* Declare the variable that will hold the values received from the queue. */
	long lReceivedValue;
	portBASE_TYPE xStatus;
	const portTickType xTicksToWait = 100 / portTICK_RATE_MS;

	/* This task is also defined within an infinite loop. */
	for( ;; )
	{
		/* As this task unblocks immediately that data is written to the queue this
		call should always find the queue empty. */
		if( uxQueueMessagesWaiting( xQueue ) != 0 )
		{
			vPrintString( "Queue should have been empty!\r\n" );
		}

		/* The first parameter is the queue from which data is to be received.  The
		queue is created before the scheduler is started, and therefore before this
		task runs for the first time.

		The second parameter is the buffer into which the received data will be
		placed.  In this case the buffer is simply the address of a variable that
		has the required size to hold the received data. 

		the last parameter is the block time � the maximum amount of time that the
		task should remain in the Blocked state to wait for data to be available should
		the queue already be empty. */
		xStatus = xQueueReceive( xQueue, &lReceivedValue, xTicksToWait );

		if( xStatus == pdPASS )
		{
			/* Data was successfully received from the queue, print out the received
			value. */
			vPrintStringAndNumber( "Received = ", lReceivedValue );
		}
		else
		{
			/* We did not receive anything from the queue even after waiting for 100ms.
			This must be an error as the sending tasks are free running and will be
			continuously writing to the queue. */
			vPrintString( "Could not receive from the queue.\r\n" );
		}
	}
}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* This function will only be called if an API call to create a task, queue
	or semaphore fails because there is too little heap RAM remaining. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( xTaskHandle *pxTask, signed char *pcTaskName )
{
	/* This function will only be called if a task overflows its stack.  Note
	that stack overflow checking does slow down the context switch
	implementation. */
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
	/* This example does not use the idle hook to perform any processing. */
}
/*-----------------------------------------------------------*/

void vApplicationTickHook( void )
{
	/* This example does not use the tick hook to perform any processing. */
}

static void init_uart3(void)
{
	PINSEL_CFG_Type PinCfg;
	UART_CFG_Type uartCfg;
	/* Initialize UART3 pin connect */
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 0;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 1;
	PINSEL_ConfigPin(&PinCfg);

	uartCfg.Baud_rate = 115200;
	uartCfg.Databits = UART_DATABIT_8;
	uartCfg.Parity = UART_PARITY_NONE;
	uartCfg.Stopbits = UART_STOPBIT_1;

	UART_Init(UART_DEV, &uartCfg);
	UART_TxCmd(UART_DEV, ENABLE);
}


static void intToString(int value, uint8_t* pBuf, uint32_t len, uint32_t base)
{
	static const char* pAscii = "0123456789abcdefghijklmnopqrstuvwxyz";
	int pos = 0;
	int tmpValue = value;

	// the buffer must not be null and at least have a length of 2 to handle one
	// digit and null-terminator
	if (pBuf == NULL || len < 2)
	{
		return;
	}

	// a valid base cannot be less than 2 or larger than 36
	// a base value of 2 means binary representation. A value of 1 would mean only zeros
	// a base larger than 36 can only be used if a larger alphabet were used.
	if (base < 2 || base > 36)
	{
		return;
	}

	// negative value
	if (value < 0)
	{
		tmpValue = -tmpValue;
		value    = -value;
		pBuf[pos++] = '-';
	}

	// calculate the required length of the buffer
	do {
		pos++;
		tmpValue /= base;
	} while(tmpValue > 0);


	if (pos > len)
	{
		// the len parameter is invalid.
		return;
	}

	pBuf[pos] = '\0';

	do {
		pBuf[--pos] = pAscii[value % base];
		value /= base;
	} while(value > 0);

	return;

}


static void init_ssp(void)
{
	SSP_CFG_Type SSP_ConfigStruct;
	PINSEL_CFG_Type PinCfg;

	/*
	 * Initialize SPI pin connect
	 * P0.7 - SCK;
	 * P0.8 - MISO
	 * P0.9 - MOSI
	 * P2.2 - SSEL - used as GPIO
	 */
	PinCfg.Funcnum = 2;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Portnum = 0;
	PinCfg.Pinnum = 7;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 8;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 9;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Funcnum = 0;
	PinCfg.Portnum = 2;
	PinCfg.Pinnum = 2;
	PINSEL_ConfigPin(&PinCfg);

	SSP_ConfigStructInit(&SSP_ConfigStruct);

	// Initialize SSP peripheral with parameter given in structure above
	SSP_Init(LPC_SSP1, &SSP_ConfigStruct);

	// Enable SSP peripheral
	SSP_Cmd(LPC_SSP1, ENABLE);

}

static void init_i2c(void)
{
	PINSEL_CFG_Type PinCfg;

	/* Initialize I2C2 pin connect */
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 10;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 11;
	PINSEL_ConfigPin(&PinCfg);

	// Initialize I2C peripheral
	I2C_Init(LPC_I2C2, 100000);

	/* Enable I2C1 operation */
	I2C_Cmd(LPC_I2C2, ENABLE);
}

static void init_adc(void)
{
	PINSEL_CFG_Type PinCfg;

	/*
	 * Init ADC pin connect
	 * AD0.0 on P0.23
	 * /

	PinCfg.Funcnum = 1;
	PinCfg.OpenDrain = 0;
	PinCfg.Pinmode = 0;
	PinCfg.Pinnum = 23;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);

	/* Configuration for ADC :
	 * 	Frequency at 1Mhz
	 *  ADC channel 0, no Interrupt
	 */
	ADC_Init(LPC_ADC, 1000000);
	ADC_IntConfig(LPC_ADC,ADC_CHANNEL_0,DISABLE);
	ADC_ChannelCmd(LPC_ADC,ADC_CHANNEL_0,ENABLE);

}

static uint32_t getTicks(void)
{
	return msTicks;
}
